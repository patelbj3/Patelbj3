package BINJU;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MAIN {
public static void main(String[] args) 
	
	{
	
		// TODO Auto-generated method stub
		String line,name="";
		String[] lineParts;
		
		System.out.println("*******************************************");
		System.out.println("     1.Married with death person           ");
		System.out.println("*******************************************");

		
		try
		
		{	
		
			FileReader d1 = new FileReader("Team 3.ged");
			BufferedReader fbuf = new BufferedReader(d1);
			BufferedReader br1 = fbuf;
			boolean flag=false,flag1=false,flag2=false,flag_spouse=false;
			String gender="",spouseid="";
			String line_spouse,spousegender="";
			String [] lineParts_spouse;
			while ((line = br1.readLine()) != null)
				
			{
			
				lineParts = line.trim().split(" ");
				if(lineParts.length>2){
	            if(lineParts[2].equalsIgnoreCase("INDI")&&flag1==true) 
	            {
	            	
	            	name="";
	            	gender="";
	            	flag=false;
	            	spouseid="";
	            	flag1=false;
	            	flag2=false;
	            	spousegender="";
	            }
	          
				}
	            
				if(lineParts[1].equalsIgnoreCase("GIVN")) 
	            
				{
	            	name=lineParts[2];
	            }
				if(lineParts[1].equalsIgnoreCase("SEX"))
				{
					gender=lineParts[2];
					//System.out.println("inside gender"+gender);
				}
				if(lineParts[1].equalsIgnoreCase("DEAT"))
				{
					flag=true;
					//System.out.println("inside Deat");
					
				}
				if(lineParts[1].equalsIgnoreCase("FAMS"))
				{
					spouseid=lineParts[2];
					flag1=true;
					
				}
				if(flag==false && flag1==true  && (!spouseid.equalsIgnoreCase("")))
				{ flag1=false;
					//System.out.println(" inside to check for death spouse spouseid"+spouseid);
					/*System.out.print("inside FAMS");
					System.out.print(" gender "+gender);
					System.out.print("flag for deat"+flag);
					System.out.println(" spouse id"+spouseid);
					System.out.println("name "+name);*/
					try
					
					{	
					
						FileReader d2 = new FileReader("Team 3.ged");
						BufferedReader bread1 = new BufferedReader(d2);
						line_spouse = bread1.readLine();
						//while ((line_spouse = bread1.readLine()) != null )
						for(;line_spouse !=null;)	
						{
							//System.out.println(" inside for");
							lineParts_spouse = line_spouse.trim().split(" ");
							//System.out.println("inside while"+lineParts_spouse[1]);
							if(lineParts_spouse.length>2)
							{
							if(lineParts_spouse[2].equalsIgnoreCase("INDI")) 
				            {
				            	//System.out.println(" reseting the value ");
								spousegender="";
								flag_spouse=false;
				            	
				            }
							}
							if(lineParts_spouse.length>1)
							{
							if(lineParts_spouse[1].equalsIgnoreCase("SEX"))
							{ 
							
								spousegender=lineParts_spouse[2];
							}
							if(lineParts_spouse[1].equalsIgnoreCase("FAMS"))
							{
								//System.out.println("inside FAMS spouse id"+lineParts_spouse[2]);
								//System.out.println("inside FAMS ");
								if(spouseid.equalsIgnoreCase(lineParts_spouse[2])&& !(spousegender.equalsIgnoreCase(gender)) && flag_spouse)
								{
									//System.out.println("name in flag2"+name);
									flag2=true;
								 break;
								}
								
							}
							if(lineParts_spouse[1].equalsIgnoreCase("DEAT"))
							{
								flag_spouse=true;
								//System.out.println("found deat");
							}
							}
							//System.out.println(" flag2"+flag2);
							line_spouse = bread1.readLine();
							//System.out.println("(line_spouse = bread1.readLine()) != null "+(() != null));
					}
						if( flag2)
						 {
							 System.out.println(name+" is married to dead person");
							 //System.out.println(" gender"+gender);
							 flag2=false;
						 }
					}
					catch(Exception e)
					{
						
					}
				}
				 
			}
			
				
		}
        
		catch(IOException ioe)
		
		{

			System.out.println("Error is :"+ioe.getMessage());
		
		}

		System.out.println("*******************************************");
		System.out.println("  2.Display grandchildren and grandparents ");
		System.out.println("*******************************************");

		
		
		//System.out.println("User Stroy 6");
		
		String temp="";
		
		String []ID= new String[50];
		String []names=new String[50];
		int x=0;
		for(int i=0;i<30;i++)
		{
			ID[i]="";
			names[i]="";
		}
		try{
			
			
			FileReader d1 = new FileReader("Team 3.ged");
			BufferedReader br1 = new BufferedReader(d1);

boolean flag1=false;

			while ((line = br1.readLine()) != null)
				
			{
				//System.out.println("x"+x);
				lineParts=line.trim().split(" ");
		
			if(lineParts.length>2){
				if(lineParts[2].equals("INDI")){
//System.out.println("helo");
					if (flag1==true)
					{
					//System.out.println("in fil "+name);
						
					/*names[x]=name;
						ID[x]=temp;
						x++;*/
						
					}
					temp=lineParts[1];
					flag1=true;
				}
				if(lineParts[1].equalsIgnoreCase("GIVN")) 
		            
				{
					name=lineParts[2];
					names[x]=name;
					ID[x]=temp;
					x++;
		        }
			}
			//System.out.println("size"+names.length);
			
			
			
		}
			
			/*System.out.println("hi");
			for(int i=0;i<=x;i++)
				System.out.println("ID "+ID[i]+" Name "+names[i]);*/
		}
		
			
		catch(Exception e)
		{
			
		}
		
		
try{
		//System.out.println("now check");	
			//for(int i=0;i<ID.length;i++)
				//System.out.println("id "+ID[i]+" name "+names[i]);
			FileReader d1 = new FileReader("Team 3.ged");
			BufferedReader br1 = new BufferedReader(d1);
			String Husb="",wife="";
			boolean found_husband=false,found_wife=false,found_child=false,found_gchild=false;
			boolean found_parent=false;
			String temp_child="";
while ((line = br1.readLine()) != null)
{
			lineParts=line.trim().split(" ");
if(lineParts.length>2)
{
	//System.out.println("entered");
			{
				if(lineParts[2].equalsIgnoreCase("FAM"))
				{
					if(found_gchild==true)		
						
					{	if(found_husband==true ||found_wife==true)
					{
						System.out.print(" are the grand children of ");
					}
						if(found_husband==true)
						{
							for(int i=0;i<names.length ;i++)
							{		 if(Husb.equalsIgnoreCase(ID[i]))
						System.out.print(names[i]);
							}
						}
						if(found_wife==true)
						{
							for(int i=0;i<names.length ;i++)
							{		 if(wife.equalsIgnoreCase(ID[i]))
							System.out.print(names[i]);
							}
						}
						if(found_husband==true ||found_wife==true)
						{
						System.out.println();
						found_husband=false;
						found_wife=false;
						found_child=false;
						found_gchild=false;
						found_parent=false;
						}
					}

					
					Husb="";
					wife="";
				}
	if(lineParts[1].equalsIgnoreCase("HUSB"))
	{
		Husb=lineParts[2];
		found_husband=true;
		//System.out.println(" found HUSB"+Husb);
		
	}
	if(lineParts[1].equalsIgnoreCase("WIFE"))
	{
		wife=lineParts[2];
		found_wife=true;
		//System.out.println("Found wife "+wife);
		
	}
	if(lineParts[1].equalsIgnoreCase("CHIL"))
			{
		found_child=true;
		///Check grand child
		temp_child=lineParts[2];
		//System.out.println("Found child "+lineParts[2]);
		
try{
			
	//System.out.println("entered 2nd" +temp_child);		
			FileReader d2 = new FileReader("Team 3.ged");
			BufferedReader br2 = new BufferedReader(d2);	
		
		
		while ((line = br2.readLine()) != null){
			lineParts=line.trim().split(" ");	
			if(lineParts.length>2)
			{
				
				if(lineParts[2].equalsIgnoreCase("FAM"))
				{
					found_parent=false;
					
				}
	if(lineParts[1].equalsIgnoreCase("HUSB")  )
	{
		if(temp_child.equalsIgnoreCase(lineParts[2]))
		{
		found_parent=true;
		//System.out.println("found parent n inner");
		}
	}
	if(lineParts[1].equalsIgnoreCase("WIFE") && temp_child.equals(lineParts[2]))
	{
		//System.out.println("found parent in inner");
		found_parent=true;
		
	}
	if(lineParts[1].equalsIgnoreCase("CHIL") &&found_parent==true)
			{
		found_gchild=true;
		///Check grand child
		for(int i=0;i<=ID.length;i++)
		{
		//System.out.println(" checking "+lineParts[2]);
			/*if(Husb.equalsIgnoreCase("@I6000000031180037265@"))
			{
				System.out.println("ID "+ID[i]+" name "+names[i]);
			System.out.println("child is "+lineParts[2]);
			}*/
		if(ID[i].equalsIgnoreCase(lineParts[2])  )
		{
			if(found_husband==true ||found_wife==true)
		System.out.print(names[i]+" ");
		break;
		}
		}
		
		
			}
		
		
		
		
		
			}
			}
}
catch(Exception e)
{
	
}
		
	/*for(int i=0;i<names.length &&!( ID[i].equalsIgnoreCase(" "));i++){
	if(found_husband==true)
	{
		
			if(Husb.equalsIgnoreCase(ID[i]))
		System.out.println(names[i]+" ");
		}
	
	if(found_wife==true){
		if(wife.equalsIgnoreCase(ID[i]))
			System.out.println(names[i]+" ");
	}
	System.out.println();*/
	}
}
		
		
			}
	}


}
catch(Exception e)
{
	
}
			
	
		
}
}