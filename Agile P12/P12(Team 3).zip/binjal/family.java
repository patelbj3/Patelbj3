package binjal;

public class family 

{
	public String fami_identifier;
	public String husband;
	public String wife;
	public String weddingDate;
	public String divorceDate;
	public String seprateDate;
	
	
	 public String getSeprateDate() {
		return seprateDate;
	}
	public void setSeprateDate(String seprateDate) {
		this.seprateDate = seprateDate;
	}
	public String getFami_identifier() {
		return fami_identifier;
	}
	public void setFami_identifier(String fami_identifier) {
		this.fami_identifier = fami_identifier;
	}
	public String getHusband() {
	  return husband;
	 }
	 public void setHusband(String husband) {
	  this.husband = husband;
	 }
	 public String getWife() {
	  return wife;
	 }
	 public void setWife(String wife) {
	  this.wife = wife;
	 }
	 public String getWeddingDate()
		{
			return weddingDate;
		}
	 public void setWeddingDate(String weddingDate)
		{
			this.weddingDate=weddingDate;
		}
	
	 public String getDivorceDate()
		{
			return divorceDate;
		}
public void setDivorceDate(String divorceDate)
	{
		this.divorceDate=divorceDate;
		
	}
	

}
